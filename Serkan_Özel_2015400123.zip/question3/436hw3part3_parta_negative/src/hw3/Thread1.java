package hw3;

public class Thread1 extends Thread {
	
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}
	
}
